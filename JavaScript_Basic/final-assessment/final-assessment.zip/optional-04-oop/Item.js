/**
 * TODO
 * Selesaikan kode pembuatan class Item dengan ketentuan:
 * - Memiliki properti `id` (number), `name` (string), `quantity` (number), dan `price` (number).
 * - Memiliki method `updateDetails()` untuk mengubah nilai `name`, `quantity`, dan `price`.
 * - Memiliki method `displayDetails()` yang mengembalikan informasi detail dari Item dengan format:
 *   ```
 *     ID: ${id}, Name: ${name}, Quantity: ${quantity}, Price: ${price}
 *   ```
 */

class Item {
  constructor(id, name, quantity, price) {
    this.id = id;
    this.name = name;
    this.quantity = Number(quantity);
    this.price = Number(price);
  }

  displayDetails() {
    return `ID: ${this.id}, Nama: ${this.name}, Jumlah: ${this.quantity}, Harga: ${this.price}`;
  }

  updateDetails(newName, newQuantity, newPrice) {
    if (newName !== undefined) this.name = newName;
    if (newQuantity !== undefined) this.quantity = Number(newQuantity);
    if (newPrice !== undefined) this.price = Number(newPrice);
  }
}


// Jangan hapus kode di bawah ini!
export default Item;
